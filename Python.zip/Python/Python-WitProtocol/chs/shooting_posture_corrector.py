# coding:UTF-8
"""
    投篮姿势纠正系统 - 可视化演示
    JY931陀螺仪 + 震动模块纠正
    
    功能：
    - 检测翻滚角(Roll)和俯仰角(Pitch)偏离
    - 超过±15°阈值时触发对应方向震动纠正
    - 四方向震动模块：上、下、左、右
"""
import tkinter as tk
from tkinter import ttk
import math
import time
import lib.device_model as deviceModel
from lib.data_processor.roles.jy901s_dataProcessor import JY901SDataProcessor
from lib.protocol_resolver.roles.wit_protocol_resolver import WitProtocolResolver


class ShootingPostureCorrector:
    """投篮姿势纠正系统"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("投篮姿势纠正系统 - JY931")
        self.root.geometry("1400x900")
        self.root.configure(bg='#1a1a2e')
        
        # 角度数据
        self.roll = 0.0   # 翻滚角 (X轴)
        self.pitch = 0.0  # 俯仰角 (Y轴)
        self.yaw = 0.0    # 偏航角 (Z轴)
        
        # 阈值设置
        self.threshold = 15.0  # 偏离阈值（度）
        
        # 震动模块状态
        self.vibration = {
            'up': False,      # 上方震动
            'down': False,    # 下方震动
            'left': False,    # 左侧震动
            'right': False    # 右侧震动
        }
        
        # 统计
        self.correct_count = 0      # 正确姿势计数
        self.correction_count = 0   # 纠正次数
        self.total_frames = 0
        
        # 设备
        self.device = None
        self.is_running = False
        
        # 历史数据
        self.history_roll = []
        self.history_pitch = []
        self.max_history = 300
        
        self.setup_ui()
        
    def setup_ui(self):
        """设置界面"""
        # 样式配置
        style = ttk.Style()
        style.configure('Title.TLabel', font=('Arial', 16, 'bold'), background='#1a1a2e', foreground='white')
        style.configure('Data.TLabel', font=('Arial', 24, 'bold'), background='#1a1a2e')
        style.configure('Status.TLabel', font=('Arial', 12), background='#1a1a2e')
        
        # 主框架
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        
        # ========== 左侧：手臂姿态可视化 ==========
        left_frame = ttk.LabelFrame(main_frame, text="手臂姿态可视化", padding=10)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        
        # 3D姿态画布
        self.canvas_arm = tk.Canvas(left_frame, bg='#16213e', width=450, height=450)
        self.canvas_arm.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # 角度数值显示
        angle_frame = ttk.Frame(left_frame)
        angle_frame.pack(fill=tk.X, pady=10)
        
        # Roll
        ttk.Label(angle_frame, text="翻滚角(Roll):", font=('Arial', 12)).grid(row=0, column=0, padx=10, sticky='e')
        self.roll_label = ttk.Label(angle_frame, text="0.0°", font=('Arial', 20, 'bold'), foreground='#e94560')
        self.roll_label.grid(row=0, column=1, padx=10)
        self.roll_bar = ttk.Progressbar(angle_frame, length=150, mode='determinate', maximum=60)
        self.roll_bar.grid(row=0, column=2, padx=10)
        self.roll_status = ttk.Label(angle_frame, text="✓", font=('Arial', 16), foreground='green')
        self.roll_status.grid(row=0, column=3, padx=5)
        
        # Pitch
        ttk.Label(angle_frame, text="俯仰角(Pitch):", font=('Arial', 12)).grid(row=1, column=0, padx=10, pady=5, sticky='e')
        self.pitch_label = ttk.Label(angle_frame, text="0.0°", font=('Arial', 20, 'bold'), foreground='#00b4d8')
        self.pitch_label.grid(row=1, column=1, padx=10)
        self.pitch_bar = ttk.Progressbar(angle_frame, length=150, mode='determinate', maximum=60)
        self.pitch_bar.grid(row=1, column=2, padx=10)
        self.pitch_status = ttk.Label(angle_frame, text="✓", font=('Arial', 16), foreground='green')
        self.pitch_status.grid(row=1, column=3, padx=5)
        
        # ========== 中间：震动模块状态 ==========
        mid_frame = ttk.LabelFrame(main_frame, text="震动模块状态", padding=10)
        mid_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        
        # 震动模块可视化画布
        self.canvas_vibration = tk.Canvas(mid_frame, bg='#0f0f23', width=300, height=400)
        self.canvas_vibration.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # 纠正提示
        self.correction_label = ttk.Label(mid_frame, text="姿势正确", font=('Arial', 14, 'bold'), foreground='green')
        self.correction_label.pack(pady=10)
        
        # 震动强度显示
        vib_info = ttk.Frame(mid_frame)
        vib_info.pack(fill=tk.X)
        ttk.Label(vib_info, text="震动强度:", font=('Arial', 11)).pack(side=tk.LEFT, padx=5)
        self.vib_intensity = ttk.Label(vib_info, text="0%", font=('Arial', 14, 'bold'), foreground='yellow')
        self.vib_intensity.pack(side=tk.LEFT)
        
        # ========== 右侧：控制与统计 ==========
        right_frame = ttk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5)
        
        # 连接状态
        conn_frame = ttk.LabelFrame(right_frame, text="连接状态", padding=10)
        conn_frame.pack(fill=tk.X, pady=5)
        
        self.status_label = ttk.Label(conn_frame, text="未连接", font=('Arial', 12))
        self.status_label.pack()
        
        self.fps_label = ttk.Label(conn_frame, text="帧率: -- Hz", font=('Arial', 11))
        self.fps_label.pack()
        
        # 按钮区域
        btn_frame = ttk.Frame(conn_frame)
        btn_frame.pack(pady=10)
        
        self.connect_btn = ttk.Button(btn_frame, text="连接设备", command=self.toggle_connection, width=12)
        self.connect_btn.pack(side=tk.LEFT, padx=5)
        
        self.reset_btn = ttk.Button(btn_frame, text="重置统计", command=self.reset_stats, width=12)
        self.reset_btn.pack(side=tk.LEFT, padx=5)
        
        # 阈值设置
        threshold_frame = ttk.LabelFrame(right_frame, text="阈值设置", padding=10)
        threshold_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(threshold_frame, text="偏离阈值:", font=('Arial', 11)).grid(row=0, column=0, padx=5, sticky='w')
        self.threshold_var = tk.StringVar(value="15")
        threshold_entry = ttk.Entry(threshold_frame, textvariable=self.threshold_var, width=8)
        threshold_entry.grid(row=0, column=1, padx=5)
        ttk.Label(threshold_frame, text="度").grid(row=0, column=2, padx=5)
        
        ttk.Button(threshold_frame, text="应用", command=self.apply_threshold, width=8).grid(row=0, column=3, padx=10)
        
        # 统计信息
        stats_frame = ttk.LabelFrame(right_frame, text="统计数据", padding=10)
        stats_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(stats_frame, text="正确姿势次数:", font=('Arial', 11)).grid(row=0, column=0, sticky='w', padx=5)
        self.correct_count_label = ttk.Label(stats_frame, text="0", font=('Arial', 14, 'bold'), foreground='green')
        self.correct_count_label.grid(row=0, column=1, padx=10)
        
        ttk.Label(stats_frame, text="纠正触发次数:", font=('Arial', 11)).grid(row=1, column=0, sticky='w', padx=5, pady=3)
        self.correction_count_label = ttk.Label(stats_frame, text="0", font=('Arial', 14, 'bold'), foreground='red')
        self.correction_count_label.grid(row=1, column=1, padx=10)
        
        ttk.Label(stats_frame, text="姿势正确率:", font=('Arial', 11)).grid(row=2, column=0, sticky='w', padx=5)
        self.accuracy_label = ttk.Label(stats_frame, text="0%", font=('Arial', 14, 'bold'), foreground='yellow')
        self.accuracy_label.grid(row=2, column=1, padx=10)
        
        # 角度历史曲线
        curve_frame = ttk.LabelFrame(right_frame, text="角度变化曲线", padding=5)
        curve_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.canvas_curve = tk.Canvas(curve_frame, bg='#0f0f23', width=280, height=200)
        self.canvas_curve.pack(fill=tk.BOTH, expand=True)
        
        # 图例
        legend_frame = ttk.Frame(curve_frame)
        legend_frame.pack(fill=tk.X)
        ttk.Label(legend_frame, text="— Roll", foreground='#e94560', font=('Arial', 9)).pack(side=tk.LEFT, padx=10)
        ttk.Label(legend_frame, text="— Pitch", foreground='#00b4d8', font=('Arial', 9)).pack(side=tk.LEFT, padx=10)
        ttk.Label(legend_frame, text="-- 阈值", foreground='#ffff00', font=('Arial', 9)).pack(side=tk.LEFT, padx=10)
        
    def apply_threshold(self):
        """应用阈值设置"""
        try:
            self.threshold = float(self.threshold_var.get())
        except:
            self.threshold = 15.0
            
    def toggle_connection(self):
        """切换连接状态"""
        if self.is_running:
            self.disconnect()
        else:
            self.connect()
            
    def connect(self):
        """连接设备"""
        self.device = deviceModel.DeviceModel(
            "JY931",
            WitProtocolResolver(),
            JY901SDataProcessor(),
            "51_0"
        )
        
        self.device.serialConfig.portName = "COM6"
        self.device.serialConfig.baud = 921600
        
        try:
            self.device.openDevice()
            self.device.dataProcessor.onVarChanged.append(self.on_data_update)
            self.is_running = True
            self.connect_btn.config(text="断开连接")
            self.status_label.config(text="已连接 COM6 @ 921600")
        except Exception as e:
            self.status_label.config(text=f"连接失败: {e}")
            
    def disconnect(self):
        """断开连接"""
        if self.device:
            self.device.closeDevice()
        self.is_running = False
        self.connect_btn.config(text="连接设备")
        self.status_label.config(text="已断开")
        
    def reset_stats(self):
        """重置统计"""
        self.correct_count = 0
        self.correction_count = 0
        self.total_frames = 0
        self.history_roll.clear()
        self.history_pitch.clear()
        
    def on_data_update(self, deviceModel):
        """数据更新回调"""
        angle_x = deviceModel.getDeviceData('angleX')
        angle_y = deviceModel.getDeviceData('angleY')
        angle_z = deviceModel.getDeviceData('angleZ')
        
        if angle_x is not None:
            self.roll = angle_x
        if angle_y is not None:
            self.pitch = angle_y
        if angle_z is not None:
            self.yaw = angle_z
            
    def calculate_vibration(self):
        """计算震动模块状态"""
        # 重置震动状态
        self.vibration = {'up': False, 'down': False, 'left': False, 'right': False}
        
        roll_deviation = abs(self.roll)
        pitch_deviation = abs(self.pitch)
        
        # pitch偏离 → 左右震动
        if self.pitch > self.threshold:
            self.vibration['left'] = True  # 向右偏，左侧震动纠正
        elif self.pitch < -self.threshold:
            self.vibration['right'] = True  # 向左偏，右侧震动纠正
            
        # roll偏离 → 上下震动
        if self.roll  > self.threshold:
            self.vibration['down'] = True  # 向上偏，下方震动纠正
        elif self.roll < -self.threshold:
            self.vibration['up'] = True  # 向下偏，上方震动纠正
            
        # 更新统计
        any_vibration = any(self.vibration.values())
        if any_vibration:
            self.correction_count += 1
        elif roll_deviation <= self.threshold and pitch_deviation <= self.threshold:
            self.correct_count += 1
            
        self.total_frames += 1
        
    def draw_arm_posture(self):
        """绘制手臂姿态可视化"""
        self.canvas_arm.delete("all")
        
        cx, cy = 225, 225
        
        # 绘制阈值区域（绿色圆环）
        r = 120
        self.canvas_arm.create_oval(cx-r, cy-r, cx+r, cy+r, outline='#00ff00', width=3, dash=(5, 5))
        
        # 绘制十字线
        self.canvas_arm.create_line(cx-150, cy, cx+150, cy, fill='#333', width=1)
        self.canvas_arm.create_line(cx, cy-150, cx, cy+150, fill='#333', width=1)
        
        # 绘制阈值线标签
        self.canvas_arm.create_text(cx+r+10, cy, text=f"+{self.threshold:.0f}°", fill='#00ff00', font=('Arial', 9))
        self.canvas_arm.create_text(cx-r-10, cy, text=f"-{self.threshold:.0f}°", fill='#00ff00', font=('Arial', 9))
        self.canvas_arm.create_text(cx, cy-r-10, text=f"-{self.threshold:.0f}°", fill='#00ff00', font=('Arial', 9))
        self.canvas_arm.create_text(cx, cy+r+10, text=f"+{self.threshold:.0f}°", fill='#00ff00', font=('Arial', 9))
        
        # 计算指针位置（Roll为X方向，Pitch为Y方向）
        # 放大显示
        scale = 4
        px = cx + self.roll * scale
        py = cy - self.pitch * scale  # Y轴反向
        
        # 绘制当前姿态点
        color = '#00ff00' if abs(self.roll) <= self.threshold and abs(self.pitch) <= self.threshold else '#ff0000'
        self.canvas_arm.create_oval(px-8, py-8, px+8, py+8, fill=color, outline='white', width=2)
        
        # 绘制轨迹线
        self.canvas_arm.create_line(cx, cy, px, py, fill=color, width=2, dash=(3, 3))
        
        # 绘制方向指示箭头
        if abs(self.roll) > 5 or abs(self.pitch) > 5:
            arrow_len = 60
            angle = math.atan2(self.pitch, self.roll)
            ax = cx + arrow_len * math.cos(angle)
            ay = cy - arrow_len * math.sin(angle)
            self.canvas_arm.create_line(cx, cy, ax, ay, fill='#ffff00', width=3, arrow=tk.LAST)
        
        # 标题
        self.canvas_arm.create_text(225, 25, text="手臂姿态俯视图", fill='white', font=('Arial', 14, 'bold'))
        
        # 当前位置标签
        self.canvas_arm.create_text(px, py-20, text=f"({self.roll:.1f}°, {self.pitch:.1f}°)", 
                                    fill='white', font=('Arial', 10))
        
    def draw_vibration_modules(self):
        """绘制震动模块状态"""
        self.canvas_vibration.delete("all")
        
        cx, cy = 150, 200
        radius = 80
        
        # 绘制中心（手臂位置）
        self.canvas_vibration.create_oval(cx-30, cy-30, cx+30, cy+30, fill='#16213e', outline='#00b4d8', width=2)
        self.canvas_vibration.create_text(cx, cy, text="手臂", fill='white', font=('Arial', 12, 'bold'))
        
        # 震动模块位置和状态
        modules = [
            ('up', cx, cy-radius-20, '上'),
            ('down', cx, cy+radius+20, '下'),
            ('left', cx-radius-20, cy, '左'),
            ('right', cx+radius+20, cy, '右'),
        ]
        
        colors = {
            True: ('#ff0000', '#ff6666'),   # 激活：红色
            False: ('#333', '#555')          # 未激活：灰色
        }
        
        for name, x, y, label in modules:
            active = self.vibration[name]
            fill_color, outline_color = colors[active]
            
            # 绘制震动模块
            self.canvas_vibration.create_rectangle(x-25, y-25, x+25, y+25, 
                                                   fill=fill_color, outline=outline_color, width=3)
            self.canvas_vibration.create_text(x, y, text=label, fill='white', font=('Arial', 12, 'bold'))
            
            # 震动动画效果
            if active:
                for i in range(3):
                    offset = (i + 1) * 5
                    self.canvas_vibration.create_rectangle(x-25-offset, y-25-offset, 
                                                          x+25+offset, y+25+offset,
                                                          outline='#ff0000', width=1, dash=(3, 3))
                    
                # 绘制震动方向箭头
                if name == 'up':
                    self.canvas_vibration.create_line(cx, cy-30, cx, cy-radius-45, 
                                                      fill='#ffff00', width=3, arrow=tk.LAST)
                elif name == 'down':
                    self.canvas_vibration.create_line(cx, cy+30, cx, cy+radius+45, 
                                                      fill='#ffff00', width=3, arrow=tk.LAST)
                elif name == 'left':
                    self.canvas_vibration.create_line(cx-30, cy, cx-radius-45, cy, 
                                                      fill='#ffff00', width=3, arrow=tk.LAST)
                elif name == 'right':
                    self.canvas_vibration.create_line(cx+30, cy, cx+radius+45, cy, 
                                                      fill='#ffff00', width=3, arrow=tk.LAST)
        
        # 图例
        self.canvas_vibration.create_rectangle(20, 380, 40, 400, fill='#ff0000', outline='#ff6666')
        self.canvas_vibration.create_text(45, 390, text="激活震动", fill='white', font=('Arial', 10), anchor='w')
        
        self.canvas_vibration.create_rectangle(120, 380, 140, 400, fill='#333', outline='#555')
        self.canvas_vibration.create_text(145, 390, text="未激活", fill='white', font=('Arial', 10), anchor='w')
        
    def draw_curve(self):
        """绘制角度曲线"""
        self.canvas_curve.delete("all")
        
        width = 270
        height = 190
        margin = 25
        
        # 网格
        for i in range(5):
            y = margin + i * (height - 2*margin) / 4
            self.canvas_curve.create_line(margin, y, width-margin, y, fill='#222', dash=(2, 2))
            
        # 零线
        y_zero = margin + (height - 2*margin) / 2
        self.canvas_curve.create_line(margin, y_zero, width-margin, y_zero, fill='#444', width=1)
        
        # 阈值线
        threshold_y_top = margin + (height - 2*margin) * (0.5 - self.threshold/60)
        threshold_y_bot = margin + (height - 2*margin) * (0.5 + self.threshold/60)
        self.canvas_curve.create_line(margin, threshold_y_top, width-margin, threshold_y_top, 
                                      fill='#ffff00', width=1, dash=(5, 3))
        self.canvas_curve.create_line(margin, threshold_y_bot, width-margin, threshold_y_bot, 
                                      fill='#ffff00', width=1, dash=(5, 3))
        
        # Y轴标签
        self.canvas_curve.create_text(12, margin, text="+30°", fill='#666', font=('Arial', 8))
        self.canvas_curve.create_text(12, height-margin, text="-30°", fill='#666', font=('Arial', 8))
        self.canvas_curve.create_text(12, y_zero, text="0°", fill='#666', font=('Arial', 8))
        
        if len(self.history_roll) < 2:
            return
            
        def draw_line(data, color):
            points = []
            n = len(data)
            for i, val in enumerate(data):
                x = margin + i * (width - 2*margin) / self.max_history
                y = margin + (height - 2*margin) * (0.5 - val/60)
                points.extend([x, y])
            if len(points) >= 4:
                self.canvas_curve.create_line(points, fill=color, width=2, smooth=True)
        
        draw_line(self.history_roll, '#e94560')
        draw_line(self.history_pitch, '#00b4d8')
        
    def update_ui(self):
        """更新UI"""
        # 轮询数据
        if self.device and self.is_running:
            angle_x = self.device.getDeviceData('angleX')
            angle_y = self.device.getDeviceData('angleY')
            if angle_x is not None:
                self.roll = angle_x
            if angle_y is not None:
                self.pitch = angle_y
        
        # 计算震动状态
        self.calculate_vibration()
        
        # 更新角度显示
        self.roll_label.config(text=f"{self.roll:.1f}°")
        self.pitch_label.config(text=f"{self.pitch:.1f}°")
        
        # 更新进度条
        self.roll_bar['value'] = abs(self.roll) + 30
        self.pitch_bar['value'] = abs(self.pitch) + 30
        
        # 更新状态标记
        roll_ok = abs(self.roll) <= self.threshold
        pitch_ok = abs(self.pitch) <= self.threshold
        
        self.roll_status.config(text="✓" if roll_ok else "✗", foreground='green' if roll_ok else 'red')
        self.pitch_status.config(text="✓" if pitch_ok else "✗", foreground='green' if pitch_ok else 'red')
        
        # 更新纠正提示
        any_vibration = any(self.vibration.values())
        if any_vibration:
            directions = [k for k, v in self.vibration.items() if v]
            self.correction_label.config(
                text=f"纠正方向: {', '.join(directions)}", 
                foreground='#ff6b6b'
            )
        else:
            self.correction_label.config(text="姿势正确 ✓", foreground='#00ff00')
        
        # 更新震动强度
        intensity = sum(self.vibration.values()) * 25
        self.vib_intensity.config(text=f"{intensity}%")
        
        # 更新统计
        self.correct_count_label.config(text=str(self.correct_count))
        self.correction_count_label.config(text=str(self.correction_count))
        accuracy = (self.correct_count / self.total_frames * 100) if self.total_frames > 0 else 0
        self.accuracy_label.config(text=f"{accuracy:.1f}%")
        
        # 添加历史数据
        self.history_roll.append(self.roll)
        self.history_pitch.append(self.pitch)
        if len(self.history_roll) > self.max_history:
            self.history_roll.pop(0)
            self.history_pitch.pop(0)
        
        # 绘制图形
        self.draw_arm_posture()
        self.draw_vibration_modules()
        self.draw_curve()
        
        self.root.after(50, self.update_ui)
        
    def run(self):
        """运行程序"""
        self.update_ui()
        self.root.mainloop()


if __name__ == '__main__':
    app = ShootingPostureCorrector()
    app.run()
