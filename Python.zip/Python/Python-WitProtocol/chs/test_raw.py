# coding:UTF-8
"""
    串口原始数据测试 - 用于诊断JY931连接
"""
import serial
import time

def test_raw_serial(port, baud):
    """直接读取串口原始数据"""
    print(f"\n测试 {port} @ {baud} baud...")
    try:
        ser = serial.Serial(port, baud, timeout=1)
        print(f"✓ 串口打开成功")
        
        # 发送Modbus读取命令: 设备地址0x50, 功能码0x03, 寄存器0x0030, 读取41个寄存器
        # 命令格式: [设备地址][功能码][寄存器地址高][寄存器地址低][数量高][数量低][CRC高][CRC低]
        cmd = bytes([0x50, 0x03, 0x00, 0x30, 0x00, 0x29, 0x44, 0xE3])
        print(f"发送命令: {cmd.hex()}")
        ser.write(cmd)
        
        # 等待响应
        time.sleep(0.5)
        
        if ser.in_waiting > 0:
            data = ser.read(ser.in_waiting)
            print(f"✓ 收到数据 ({len(data)} 字节): {data.hex()}")
            return True
        else:
            print("✗ 无响应数据")
            
            # 尝试其他设备地址
            for addr in [0x01, 0x02, 0x50, 0x51, 0x52]:
                ser.flushInput()
                cmd = bytes([addr, 0x03, 0x00, 0x30, 0x00, 0x29])
                # 简单CRC计算
                crc = compute_crc(cmd)
                cmd_full = cmd + bytes([crc >> 8, crc & 0xff])
                print(f"尝试地址 0x{addr:02X}: 发送 {cmd_full.hex()}")
                ser.write(cmd_full)
                time.sleep(0.3)
                if ser.in_waiting > 0:
                    data = ser.read(ser.in_waiting)
                    print(f"✓ 收到数据: {data.hex()}")
                    ser.close()
                    return True
                time.sleep(0.1)
        
        ser.close()
        return False
        
    except Exception as e:
        print(f"✗ 错误: {e}")
        return False

def compute_crc(data):
    """计算Modbus CRC16"""
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x0001:
                crc = (crc >> 1) ^ 0xA001
            else:
                crc >>= 1
    return crc

if __name__ == '__main__':
    print("=" * 50)
    print("JY931 串口原始数据诊断测试")
    print("=" * 50)
    
    # 测试不同配置
    configs = [
        ("COM3", 115200),
        ("COM3", 9600),
        ("COM1", 115200),
        ("COM1", 9600),
    ]
    
    for port, baud in configs:
        if test_raw_serial(port, baud):
            print(f"\n找到响应! 配置: {port} @ {baud}")
            break
        time.sleep(0.5)
    else:
        print("\n未检测到设备响应，请检查:")
        print("1. 设备是否上电")
        print("2. 串口线是否正确连接(TX/RX)")
        print("3. 是否需要USB转RS485转换器")
