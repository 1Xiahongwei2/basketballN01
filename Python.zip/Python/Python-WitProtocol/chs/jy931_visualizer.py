# coding:UTF-8
"""
    JY931 陀螺仪可视化演示程序
    - 检测帧频率
    - 3D姿态可视化
    - 实时数据曲线
"""
import tkinter as tk
from tkinter import ttk
import math
import time
import threading
import lib.device_model as deviceModel
from lib.data_processor.roles.jy901s_dataProcessor import JY901SDataProcessor
from lib.protocol_resolver.roles.wit_protocol_resolver import WitProtocolResolver

class JY931Visualizer:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("JY931 陀螺仪可视化演示")
        self.root.geometry("1200x800")
        self.root.configure(bg='#1a1a2e')
        
        # 数据
        self.angle_x = 0.0
        self.angle_y = 0.0
        self.angle_z = 0.0
        self.chip_time = ""
        
        # 帧频率统计
        self.frame_count = 0
        self.count_0x50 = 0
        self.count_0x53 = 0
        self.frame_times = []
        self.fps = 0
        self.start_time = time.time()
        
        # 历史数据用于曲线
        self.history_x = []
        self.history_y = []
        self.history_z = []
        self.max_history = 200
        
        # 设备
        self.device = None
        self.is_running = False
        
        self.setup_ui()
        
    def setup_ui(self):
        """设置界面"""
        # 主框架
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 左侧 - 3D姿态显示
        left_frame = ttk.LabelFrame(main_frame, text="3D姿态显示")
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        
        self.canvas_3d = tk.Canvas(left_frame, bg='#16213e', width=500, height=500)
        self.canvas_3d.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 右侧
        right_frame = ttk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5)
        
        # 状态信息
        status_frame = ttk.LabelFrame(right_frame, text="连接状态")
        status_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.status_label = ttk.Label(status_frame, text="未连接", font=('Arial', 12))
        self.status_label.pack(pady=5)
        
        self.fps_label = ttk.Label(status_frame, text="帧率: -- Hz", font=('Arial', 14, 'bold'))
        self.fps_label.pack(pady=5)
        
        # 数据显示
        data_frame = ttk.LabelFrame(right_frame, text="欧拉角数据")
        data_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Roll
        ttk.Label(data_frame, text="Roll (X):", font=('Arial', 11)).grid(row=0, column=0, padx=10, pady=5, sticky='w')
        self.roll_label = ttk.Label(data_frame, text="0.000°", font=('Arial', 16, 'bold'), foreground='#e94560')
        self.roll_label.grid(row=0, column=1, padx=10, pady=5)
        self.roll_bar = ttk.Progressbar(data_frame, length=200, mode='determinate', maximum=360)
        self.roll_bar.grid(row=0, column=2, padx=10, pady=5)
        
        # Pitch
        ttk.Label(data_frame, text="Pitch (Y):", font=('Arial', 11)).grid(row=1, column=0, padx=10, pady=5, sticky='w')
        self.pitch_label = ttk.Label(data_frame, text="0.000°", font=('Arial', 16, 'bold'), foreground='#0f3460')
        self.pitch_label.grid(row=1, column=1, padx=10, pady=5)
        self.pitch_bar = ttk.Progressbar(data_frame, length=200, mode='determinate', maximum=360)
        self.pitch_bar.grid(row=1, column=2, padx=10, pady=5)
        
        # Yaw
        ttk.Label(data_frame, text="Yaw (Z):", font=('Arial', 11)).grid(row=2, column=0, padx=10, pady=5, sticky='w')
        self.yaw_label = ttk.Label(data_frame, text="0.000°", font=('Arial', 16, 'bold'), foreground='#00b4d8')
        self.yaw_label.grid(row=2, column=1, padx=10, pady=5)
        self.yaw_bar = ttk.Progressbar(data_frame, length=200, mode='determinate', maximum=360)
        self.yaw_bar.grid(row=2, column=2, padx=10, pady=5)
        
        # 芯片时间
        ttk.Label(data_frame, text="芯片时间:", font=('Arial', 11)).grid(row=3, column=0, padx=10, pady=5, sticky='w')
        self.time_label = ttk.Label(data_frame, text="--", font=('Arial', 12))
        self.time_label.grid(row=3, column=1, columnspan=2, padx=10, pady=5, sticky='w')
        
        # 帧统计
        stats_frame = ttk.LabelFrame(right_frame, text="帧统计")
        stats_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.frame_count_label = ttk.Label(stats_frame, text="总帧数: 0", font=('Arial', 11))
        self.frame_count_label.pack(pady=2)
        
        self.avg_fps_label = ttk.Label(stats_frame, text="平均帧率: -- Hz", font=('Arial', 11))
        self.avg_fps_label.pack(pady=2)
        
        self.time_0x50_label = ttk.Label(stats_frame, text="时间包(0x50): 0", font=('Arial', 11))
        self.time_0x50_label.pack(pady=2)
        
        self.angle_0x53_label = ttk.Label(stats_frame, text="角度包(0x53): 0", font=('Arial', 11))
        self.angle_0x53_label.pack(pady=2)
        
        # 曲线显示
        curve_frame = ttk.LabelFrame(right_frame, text="角度变化曲线")
        curve_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.canvas_curve = tk.Canvas(curve_frame, bg='#0f0f23', width=400, height=200)
        self.canvas_curve.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 按钮
        btn_frame = ttk.Frame(right_frame)
        btn_frame.pack(fill=tk.X, padx=5, pady=10)
        
        self.connect_btn = ttk.Button(btn_frame, text="连接设备", command=self.toggle_connection)
        self.connect_btn.pack(side=tk.LEFT, padx=5)
        
        self.reset_btn = ttk.Button(btn_frame, text="重置统计", command=self.reset_stats)
        self.reset_btn.pack(side=tk.LEFT, padx=5)
        
        # 统计变量
        self.count_0x50 = 0
        self.count_0x53 = 0
        
    def toggle_connection(self):
        """切换连接状态"""
        if self.is_running:
            self.disconnect()
        else:
            self.connect()
            
    def connect(self):
        """连接设备"""
        self.device = deviceModel.DeviceModel(
            "JY931",
            WitProtocolResolver(),
            JY901SDataProcessor(),
            "51_0"
        )
        
        self.device.serialConfig.portName = "COM3"
        self.device.serialConfig.baud = 921600
        
        try:
            self.device.openDevice()
            self.device.dataProcessor.onVarChanged.append(self.on_data_update)
            self.is_running = True
            self.connect_btn.config(text="断开连接")
            self.status_label.config(text="已连接 COM3 @ 921600")
            self.start_time = time.time()
            self.frame_count = 0
            self.count_0x50 = 0
            self.count_0x53 = 0
        except Exception as e:
            self.status_label.config(text=f"连接失败: {e}")
            
    def disconnect(self):
        """断开连接"""
        if self.device:
            self.device.closeDevice()
        self.is_running = False
        self.connect_btn.config(text="连接设备")
        self.status_label.config(text="已断开")
        
    def reset_stats(self):
        """重置统计"""
        self.frame_count = 0
        self.count_0x50 = 0
        self.count_0x53 = 0
        self.start_time = time.time()
        self.frame_times.clear()
        self.history_x.clear()
        self.history_y.clear()
        self.history_z.clear()
        
    def on_data_update(self, deviceModel):
        """数据更新回调 - SDK已修复，所有包都会触发"""
        now = time.time()
        self.frame_count += 1
        self.frame_times.append(now)
        
        # 保留最近1秒计算实时帧率
        self.frame_times = [t for t in self.frame_times if t > now - 1.0]
        self.fps = len(self.frame_times)
        
        # 读取角度
        angle_x = deviceModel.getDeviceData('angleX')
        angle_y = deviceModel.getDeviceData('angleY')
        angle_z = deviceModel.getDeviceData('angleZ')
        chip_time = deviceModel.getDeviceData('Chiptime')
        
        if angle_x is not None:
            self.angle_x = angle_x
            self.count_0x53 += 1
        if angle_y is not None:
            self.angle_y = angle_y
        if angle_z is not None:
            self.angle_z = angle_z
        if chip_time is not None:
            self.chip_time = chip_time
            self.count_0x50 += 1
    
    def poll_device_data(self):
        """从设备数据字典直接轮询数据"""
        if not self.device or not self.is_running:
            return
        angle_x = self.device.getDeviceData('angleX')
        angle_y = self.device.getDeviceData('angleY')
        angle_z = self.device.getDeviceData('angleZ')
        chip_time = self.device.getDeviceData('Chiptime')
        if angle_x is not None:
            self.angle_x = angle_x
        if angle_y is not None:
            self.angle_y = angle_y
        if angle_z is not None:
            self.angle_z = angle_z
        if chip_time is not None:
            self.chip_time = chip_time
            
    def draw_3d_cube(self):
        """绘制3D立方体表示姿态"""
        self.canvas_3d.delete("all")
        
        cx, cy = 250, 250  # 中心点
        size = 80  # 立方体大小
        
        # 转换角度为弧度
        roll = math.radians(self.angle_x)
        pitch = math.radians(self.angle_y)
        yaw = math.radians(self.angle_z)
        
        # 立方体顶点
        vertices = [
            [-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1],
            [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]
        ]
        
        # 旋转矩阵
        def rotate_point(p):
            x, y, z = p
            
            # Roll (绕X轴)
            y1 = y * math.cos(roll) - z * math.sin(roll)
            z1 = y * math.sin(roll) + z * math.cos(roll)
            x1 = x
            
            # Pitch (绕Y轴)
            x2 = x1 * math.cos(pitch) + z1 * math.sin(pitch)
            z2 = -x1 * math.sin(pitch) + z1 * math.cos(pitch)
            y2 = y1
            
            # Yaw (绕Z轴)
            x3 = x2 * math.cos(yaw) - y2 * math.sin(yaw)
            y3 = x2 * math.sin(yaw) + y2 * math.cos(yaw)
            z3 = z2
            
            return [x3, y3, z3]
        
        # 旋转并投影
        projected = []
        for v in vertices:
            r = rotate_point(v)
            # 简单透视投影
            scale = 2 / (3 - r[2])
            px = cx + r[0] * size * scale
            py = cy + r[1] * size * scale
            projected.append((px, py))
        
        # 绘制面 (后面的面先画)
        faces = [
            ([0, 1, 2, 3], '#1a1a2e'),  # 后
            ([4, 5, 6, 7], '#e94560'),  # 前 - 红色
            ([0, 1, 5, 4], '#16213e'),  # 下
            ([2, 3, 7, 6], '#0f3460'),  # 上
            ([0, 3, 7, 4], '#00b4d8'),  # 左 - 蓝色
            ([1, 2, 6, 5], '#00b4d8'),  # 右 - 蓝色
        ]
        
        # 按z深度排序
        def face_depth(face):
            idx = face[0]
            return sum(rotate_point(vertices[i])[2] for i in idx) / 4
        
        faces.sort(key=face_depth)
        
        for idxs, color in faces:
            points = []
            for i in idxs:
                points.extend(projected[i])
            self.canvas_3d.create_polygon(points, fill=color, outline='white', width=2)
        
        # 绘制坐标轴
        axis_len = 120
        axes = [
            ([1, 0, 0], '#e94560', 'X'),  # 红
            ([0, 1, 0], '#00ff00', 'Y'),  # 绿
            ([0, 0, 1], '#00b4d8', 'Z'),  # 蓝
        ]
        
        for axis, color, label in axes:
            r = rotate_point(axis)
            scale = 2 / (3 - r[2])
            ex = cx + r[0] * axis_len * scale
            ey = cy + r[1] * axis_len * scale
            self.canvas_3d.create_line(cx, cy, ex, ey, fill=color, width=3, arrow=tk.LAST)
            self.canvas_3d.create_text(ex + 10, ey, text=label, fill=color, font=('Arial', 12, 'bold'))
        
        # 标题
        self.canvas_3d.create_text(250, 30, text="3D姿态可视化", fill='white', font=('Arial', 14, 'bold'))
        
    def draw_curve(self):
        """绘制角度曲线"""
        self.canvas_curve.delete("all")
        
        width = 390
        height = 190
        margin = 10
        
        # 绘制网格
        for i in range(5):
            y = margin + i * (height - 2 * margin) / 4
            self.canvas_curve.create_line(margin, y, width - margin, y, fill='#333', dash=(2, 2))
            
        for i in range(5):
            x = margin + i * (width - 2 * margin) / 4
            self.canvas_curve.create_line(x, margin, x, height - margin, fill='#333', dash=(2, 2))
        
        # Y轴标签
        self.canvas_curve.create_text(25, margin, text="180°", fill='#666', font=('Arial', 8))
        self.canvas_curve.create_text(25, height - margin, text="-180°", fill='#666', font=('Arial', 8))
        
        if len(self.history_x) < 2:
            return
            
        def draw_line(data, color):
            points = []
            n = len(data)
            for i, val in enumerate(data):
                x = margin + i * (width - 2 * margin) / self.max_history
                # 将-180~180映射到画布高度
                y = margin + (height - 2 * margin) / 2 - (val / 180) * (height - 2 * margin) / 2
                points.extend([x, y])
            if len(points) >= 4:
                self.canvas_curve.create_line(points, fill=color, width=2, smooth=True)
        
        draw_line(self.history_x, '#e94560')  # Roll - 红
        draw_line(self.history_y, '#00ff00')  # Pitch - 绿
        draw_line(self.history_z, '#00b4d8')  # Yaw - 蓝
        
        # 图例
        self.canvas_curve.create_text(50, height - 10, text="Roll", fill='#e94560', font=('Arial', 9))
        self.canvas_curve.create_text(100, height - 10, text="Pitch", fill='#00ff00', font=('Arial', 9))
        self.canvas_curve.create_text(160, height - 10, text="Yaw", fill='#00b4d8', font=('Arial', 9))
        
    def update_ui(self):
        """更新UI"""
        # 轮询补充数据（防止回调遗漏）
        self.poll_device_data()
        
        if self.is_running:
            # 添加历史数据
            self.history_x.append(self.angle_x)
            self.history_y.append(self.angle_y)
            self.history_z.append(self.angle_z)
            if len(self.history_x) > self.max_history:
                self.history_x.pop(0)
                self.history_y.pop(0)
                self.history_z.pop(0)
            
            # 更新帧率
            self.fps_label.config(text=f"帧率: {self.fps} Hz")
            
            # 更新角度
            self.roll_label.config(text=f"{self.angle_x:.3f}°")
            self.pitch_label.config(text=f"{self.angle_y:.3f}°")
            self.yaw_label.config(text=f"{self.angle_z:.3f}°")
            
            self.roll_bar['value'] = (self.angle_x + 180) % 360
            self.pitch_bar['value'] = (self.angle_y + 180) % 360
            self.yaw_bar['value'] = (self.angle_z + 180) % 360
            
            self.time_label.config(text=self.chip_time if self.chip_time else "--")
            
            elapsed = time.time() - self.start_time
            avg_fps = self.frame_count / elapsed if elapsed > 0 else 0
            self.frame_count_label.config(text=f"总帧数: {self.frame_count}")
            self.avg_fps_label.config(text=f"平均帧率: {avg_fps:.1f} Hz")
            self.time_0x50_label.config(text=f"时间包(0x50): {self.count_0x50}")
            self.angle_0x53_label.config(text=f"角度包(0x53): {self.count_0x53}")
        
        self.draw_3d_cube()
        self.draw_curve()
        
        self.root.after(50, self.update_ui)
        
    def run(self):
        """运行程序"""
        self.update_ui()
        self.root.mainloop()

if __name__ == '__main__':
    app = JY931Visualizer()
    app.run()
