# coding:UTF-8
"""
    JY931陀螺仪测试脚本
    支持: 维特标准协议(WitProtocol) 和 RS485协议(Modbus)
"""
import time
import threading
import lib.device_model as deviceModel
from lib.data_processor.roles.jy901s_dataProcessor import JY901SDataProcessor
from lib.protocol_resolver.roles.wit_protocol_resolver import WitProtocolResolver
from lib.protocol_resolver.roles.protocol_485_resolver import Protocol485Resolver

welcome = """
============================================
  维特智能 JY931 陀螺仪测试程序
  WitMotion JY931 Gyroscope Test Program
============================================
"""

def onUpdate(deviceModel):
    """数据更新回调"""
    global data_count
    data_count += 1
    print(f"\n[{data_count}] 传感器数据:")
    print(f"  温度: {deviceModel.getDeviceData('temperature')} °C")
    print(f"  加速度(g): X={deviceModel.getDeviceData('accX')}, Y={deviceModel.getDeviceData('accY')}, Z={deviceModel.getDeviceData('accZ')}")
    print(f"  角速度(°/s): X={deviceModel.getDeviceData('gyroX')}, Y={deviceModel.getDeviceData('gyroY')}, Z={deviceModel.getDeviceData('gyroZ')}")
    print(f"  角度(°): X={deviceModel.getDeviceData('angleX')}, Y={deviceModel.getDeviceData('angleY')}, Z={deviceModel.getDeviceData('angleZ')}")
    print(f"  磁场: X={deviceModel.getDeviceData('magX')}, Y={deviceModel.getDeviceData('magY')}, Z={deviceModel.getDeviceData('magZ')}")

def print_data_periodically(device):
    """定时打印数据 - 不依赖回调"""
    import time
    while device.isOpen:
        time.sleep(0.5)
        print(f"\n========== 传感器数据 ==========")
        print(f"温度: {device.getDeviceData('temperature')} °C")
        print(f"加速度(g): X={device.getDeviceData('accX')}, Y={device.getDeviceData('accY')}, Z={device.getDeviceData('accZ')}")
        print(f"角速度(°/s): X={device.getDeviceData('gyroX')}, Y={device.getDeviceData('gyroY')}, Z={device.getDeviceData('gyroZ')}")
        print(f"角度(°): X={device.getDeviceData('angleX')}, Y={device.getDeviceData('angleY')}, Z={device.getDeviceData('angleZ')}")
        print(f"磁场: X={device.getDeviceData('magX')}, Y={device.getDeviceData('magY')}, Z={device.getDeviceData('magZ')}")
        print("================================")

data_count = 0

def loop_read_thread(device):
    """循环读取数据线程 - RS485协议需要主动读取"""
    while device.isOpen:
        device.readReg(0x30, 41)  # 读取传感器数据
        time.sleep(0.1)  # 100ms读取一次

def test_connection(port_name, baud_rate, use_485=False):
    """测试连接"""
    print(f"\n尝试连接: {port_name}, 波特率: {baud_rate}, 协议: {'RS485/Modbus' if use_485 else '维特标准协议'}")
    
    # 选择协议解析器
    if use_485:
        resolver = Protocol485Resolver()
    else:
        resolver = WitProtocolResolver()
    
    # 初始化设备
    device = deviceModel.DeviceModel(
        "JY931",
        resolver,
        JY901SDataProcessor(),
        "51_0"
    )
    
    device.ADDR = 0x50  # 设备地址
    device.serialConfig.portName = port_name
    device.serialConfig.baud = baud_rate
    
    try:
        device.openDevice()
        print("✓ 串口打开成功!")
    except Exception as e:
        print(f"✗ 连接失败: {e}")
        return None
    
    # 注册数据回调
    device.dataProcessor.onVarChanged.append(onUpdate)
    
    # 启动定时打印线程
    print("启动数据监控...")
    t_print = threading.Thread(target=print_data_periodically, args=(device,), daemon=True)
    t_print.start()
    
    # 如果是RS485协议，启动主动读取线程
    if use_485:
        print("启动主动读取线程(RS485模式)...")
        t = threading.Thread(target=loop_read_thread, args=(device,), daemon=True)
        t.start()
    
    return device

if __name__ == '__main__':
    print(welcome)
    
    # 测试配置列表: (端口, 波特率, 是否RS485协议)
    # JY931使用维特标准协议，波特率921600
    test_configs = [
        ("COM3", 921600, False),    # 维特协议, 921600 - 首选
        ("COM3", 115200, False),    # 维特协议, 115200
        ("COM3", 9600, False),      # 维特协议, 9600
    ]
    
    device = None
    for port, baud, use_485 in test_configs:
        device = test_connection(port, baud, use_485)
        if device:
            break
        time.sleep(0.5)
    
    if not device:
        print("\n所有配置尝试失败！请检查:")
        print("1. 陀螺仪是否正确连接到电脑")
        print("2. 设备管理器中查看正确的COM口号")
        print("3. 确认设备型号和波特率")
        exit(1)
    
    print("\n开始接收数据 (按 Enter 键退出)...\n")
    
    try:
        input()
    except KeyboardInterrupt:
        pass
    
    device.closeDevice()
    print("\n测试结束，设备已关闭")
