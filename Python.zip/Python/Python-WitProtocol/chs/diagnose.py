# coding:UTF-8
"""
    详细诊断脚本 - 查看原始数据并解析
"""
import serial
import time

def analyze_wit_data(data):
    """分析维特协议数据"""
    frames = []
    i = 0
    while i < len(data) - 10:
        if data[i] == 0x55:
            frame_type = data[i+1] if i+1 < len(data) else 0
            if 0x50 <= frame_type <= 0x5f:
                # 可能是有效帧
                frame = data[i:i+11]
                # 计算校验和
                checksum = sum(frame[:10]) & 0xff
                if checksum == frame[10]:
                    frames.append({
                        'type': hex(frame_type),
                        'raw': frame.hex(),
                        'valid': True
                    })
                    i += 11
                    continue
        i += 1
    return frames

print("=" * 60)
print("JY931 详细诊断 - COM3 @ 921600")
print("=" * 60)

try:
    ser = serial.Serial('COM3', 921600, timeout=2)
    print(f"✓ 串口打开成功")
    
    print("\n等待接收数据 (3秒)...")
    time.sleep(1)
    
    # 清空缓冲区
    ser.flushInput()
    time.sleep(2)
    
    if ser.in_waiting > 0:
        raw_data = ser.read(ser.in_waiting)
        print(f"\n接收到 {len(raw_data)} 字节原始数据:")
        print(f"前100字节: {raw_data[:100].hex()}")
        
        # 分析帧
        frames = analyze_wit_data(raw_data)
        print(f"\n发现 {len(frames)} 个有效帧:")
        for f in frames[:10]:
            print(f"  类型: {f['type']}, 数据: {f['raw']}")
        
        # 查找55 51 (加速度包)
        if b'\x55\x51' in raw_data:
            idx = raw_data.find(b'\x55\x51')
            print(f"\n找到加速度包 @ 索引 {idx}: {raw_data[idx:idx+11].hex()}")
        
        # 查找55 52 (角速度包)  
        if b'\x55\x52' in raw_data:
            idx = raw_data.find(b'\x55\x52')
            print(f"找到角速度包 @ 索引 {idx}: {raw_data[idx:idx+11].hex()}")
            
        # 查找55 53 (角度包)
        if b'\x55\x53' in raw_data:
            idx = raw_data.find(b'\x55\x53')
            print(f"找到角度包 @ 索引 {idx}: {raw_data[idx:idx+11].hex()}")
            
    else:
        print("无数据接收")
    
    ser.close()
    
except Exception as e:
    print(f"错误: {e}")
